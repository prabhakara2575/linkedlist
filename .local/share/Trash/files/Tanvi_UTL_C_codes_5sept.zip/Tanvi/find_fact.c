#include<stdio.h>

int
fact (int a)
{
  if (a <= 1)
    return (1);
  else
    return a * fact (a - 1);
}

void
main ()
{
  int x;
  printf ("Enter a no.:");
  scanf ("%d", &x);
  printf ("factorial of %d : %d \n", x, fact (x));
}
