#include<stdio.h>
void main()
{
	int x;
	printf("Enter the no of rows");
	scanf("%d",&x);

	///triangle with different no.
	printf("Pattern 1 \n");
	for(int i=1;i<=x;i++)
	{
		for(int j=1;j<=i;j++)
		{
			printf("%d ",j);
		}
		printf("\n");
	}


	///triangle with same no.
	printf("Pattern 2 \n");
	for(int i=1;i<=x;i++)
	{
		for(int j=1;j<=i;j++)
		{
			printf("%d ",i);
		}
		printf("\n");
	}
	
	printf("Pattern 3 \n");
	for(int i=x;i>=0;i--)
	{
		for(int j=i;j>0;j--)
		{
			printf(" ");
		}
		for(int k=1;k<=x-i;k++)
		{
			printf("*");
		} 
		printf("\n");
	}

	
	printf("Pattern 4 \n");
	for(int i=0;i<x;i++)
	{
		for(int j=0;j<x;j++)
		{	
			
			if(j+i>2){
				
				printf("*");
			}
			else
				printf(" ");
			
		}
		printf("\n");
	}
	





	//Pascal's triangle
	printf("Pascals Triangle \n");
	for(int i=x;i>=0;i--)
	{
		for(int j=i;j>=(i/2);j--)
		{
			printf("*");
		}
		for(int k=1;k<x-i;k++)
		{
			printf("%d",k);
		}
 		for(int l=x-i;l>0;l--)
		{
			printf("%d",l);
		}
		printf("\n");
	}

	for(int i=0;i<x;i++)
	{
		
		for(int j=0;j<x;j++)
		{	
			int m=i;
			if(j+i>2){
				while(m<=i)
				{	printf("%d",m);
					m++;}
				while(m>=1)
				{	printf("%d",m);
					m--;}
				break;
			}
			else
				printf(" ");
			
		}
		printf("\n");
	}
	/*
	for(int i=0;i<x;i++)
	{
		for(int j=0;j<x;j++)
		{	
			printf(" ");
			if(j+i>2){
				printf("*");
			}
		}
		printf("\n");
	}
	*/

}
