#include<stdio.h>
void main()
{
	int a,b=0;	
	printf("Enter two no.:");
	scanf("%d %d",&a,&b);
	printf("The addition of %d and %d is %d \n",a,b,a+b);
	printf("The subtraction of %d and %d is %d \n",a,b,a-b);
	printf("The multiplication of %d and %d is %d \n",a,b,a*b);
	printf("The division of %d and %d is %d \n",a,b,a/b);		

}
