#include<stdio.h>
void main()
{
	printf("Who is the cricket captian?\n a Sachin \t b Dhoni \n c Virat \t d Rohit\n" );
	char x;
	scanf("%c",&x);
	switch(x)
	{
		case 'a': {
			printf("You are wrong .Sachin is not the captian");
			break;
			}
		case 'b': {
			printf("You are wrong .Dhooni was the captian till 2014  ");
			break;
			}
		case 'c': {
			printf("You are correct");
			break;
			}
		case 'd': {
			printf("You are wrong .Rohit is  the vice captian");
			break;
			}
		default:
			printf("Please select from the option");

	}




}
