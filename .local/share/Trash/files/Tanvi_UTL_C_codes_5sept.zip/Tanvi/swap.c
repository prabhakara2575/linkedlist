#include<stdio.h>
void main()
{
	int x,y;
	printf("Enter two no");
	scanf("%d %d",&x,&y);
	printf("The no are x=%d y=%d \n",x,y);
	x=x^y;
	y=x^y;
	x=x^y;
	printf("The swapped no are x=%d y=%d",x,y);

}
