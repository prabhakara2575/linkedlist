#include<stdio.h>

int add(int a,int b)
{
	if (!a)
	return b;
	else
		return add((a&b)<<1,a^b);	
}
void main()
{
	printf("addition is :%d",add(5,6));	
}
