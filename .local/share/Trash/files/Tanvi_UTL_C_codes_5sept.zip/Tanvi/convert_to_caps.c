#include<stdio.h>
void main()
{
	char x,y;
	printf("Enter the letter:");	
	scanf("%c",&x);
	printf("%d \n",x);
	y=x-32;
	printf("%d \n",y);
	printf("the uppercase is: %c \n",y);
	y=y+1;
	printf("the next uppercase is: %c \n",y);
	
	if(x=='a'|| x=='e'|| x=='i'||x=='o'||x=='u')
		printf("The letter is vowel \n");
	else
		printf("The letter is not a vowel \n");
}
	
