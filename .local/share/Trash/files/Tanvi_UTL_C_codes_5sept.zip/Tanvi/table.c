#include<stdio.h>
void main()
{
	int x;
	printf("Enter no");
	scanf("%d",&x);
	printf("The table for %d is :",x);
	for(int i=1;i<11;i++)
	{
		printf("%d ",x*i);
	}
}
