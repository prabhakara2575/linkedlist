#include<stdio.h>
void main()
{
	int x='c';	
	printf(" no.:%d \n",x);
	//scanf("%d %d",&a,&b);
	char y='a';
	printf(" no.:%c \n",y);

}

