#include<stdio.h>
void main()
{
	char name[10];	
	int x;
	printf("Enter your name");
	scanf("%s",name);	
	printf("Rate youself between 0-10 \n");
	scanf("%d",&x);
	if(x>7)
		printf("You are cool %s \n",name);
	else
		printf("Better luck next time\n");
}

	
