#include<stdio.h>

int mod(int a)
{
	if(a<0)
		return (-a);
	else
		return a;
}
void main()
{
	int x;
	printf("Enter a no.:");
	scanf("%d",&x);	
	printf("Absolute of %d : %d \n",x,mod(x));
}
